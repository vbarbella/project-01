var inStock;
var shipping;
inStock = true;
shipping = false;

/*Somewhat confused as to what the example in the book said here about the code changing and wondering if the just page runs the last correct value assigned no matter what is above it?*/

inStock = false;
shipping = true;

/*the page looks correct so far: showing shipping but not availibility I just want to test that the page reflects the bottom most command here so I am going to flip it again*/

inStock = true;
shipping = true;

/*ok looks like that was right lol, yay*/

inStock = false;
shipping = true;

var elStock = document.getElementById('stock');
elStock.className = inStock;
var elShip = document .getElementById('shipping');
elShip.className = shipping; 