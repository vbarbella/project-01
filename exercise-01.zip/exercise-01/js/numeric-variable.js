/*Changing the cost from price per tile to reflect the total cost of the sign*/

var price = 5;
var quantity = 14;
var total;

total = price * quantity;

var el = document.getElementById('cost');
el.textContent = '$' + total;

