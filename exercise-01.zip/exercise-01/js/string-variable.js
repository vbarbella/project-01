/*for the sake of abbreviation i am declaring the variables in the same line that i list them*/

var username = 'Molly';
var message = 'See our upcoming range...';

var elName = document.getElementById('name');
elName.textContent = username;
var elNote = document.getElementById('note');
elNote.textContent = message;
