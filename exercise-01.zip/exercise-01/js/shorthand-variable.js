/*Learning you can place variables on the same line, but would avoid doing often, as to not clutter the js*/
var price = 5, quantity = 14;
var total = price * quantity;

var el = document.getElementById('cost');
el.textContent = '$' + total;