/*Assigning true or false to availibility and available shipping*/
var inStock;
var shipping;
inStock = true;
shipping = false;

var elStock = document.getElementById('stock');
elStock.className = inStock;
var elShip = document .getElementById('shipping');
elShip.className = shipping;