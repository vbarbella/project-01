/*When apostrophes appear in strings, surround in double quotes*/
var title = "Molly's Special Offers";
/*When double quotes appear in strings, a '\' before the quote will tell the code it is part of the string rather than the end.*/
var message = '<a href=\"sale.html\">25% off!</a>';

var elTitle = document.getElementById('title');
elTitle.innerHTML = title;
var elNote = document.getElementById('note');
elNote.innerHTML = message; 