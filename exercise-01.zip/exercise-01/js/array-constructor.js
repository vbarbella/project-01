var colors = new Array('white', 'black', 'custom');

var el = document.getElementById('colors');
el.innerHTML = colors.item(0);

/* I'm not sure of my problem here, the Inspect element on the webpage says '.item(0);' isnt a function though I've copied whats in the book */
